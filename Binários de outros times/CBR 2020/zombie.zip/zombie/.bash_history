ls
cd
ls
ls -l bin/
vi start
ls -l
cd ..
sudo cp -R /home/zombie_gear /media/6B774FCE320C5323/
exit
cd
ls
ls -l
more start
./bin/zgear 
exit
cd
ls
ls -l
exit
cd
pwd
ls
more start
ls -l
./start.sh 
ls -l
cd 
ls
cd
ls
more start
more bin/zgear 
