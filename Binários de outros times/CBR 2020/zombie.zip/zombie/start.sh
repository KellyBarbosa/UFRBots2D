#!/bin/bash

HOST="localhost"
PORT="6000"
VERSION="bin"
BINARY="zgear"
TEAM_NAME="zgear"

CLIENT="./bin/zgear"
LOG_DIR="logs"
mkdir $LOG_DIR 2>/dev/null
SLEEP_TIME=0.1

COACH_PORT=`expr $PORT + 1`
OLCOACH_PORT=`expr $PORT + 2`
N_PARAM="-team_name $TEAM_NAME -host $HOST -port $PORT -coach_port $COACH_PORT -olcoach_port $OLCOACH_PORT -log_dir $LOG_DIR"
G_PARAM="$N_PARAM -goalie on"
C_PARAM="$N_PARAM -coach on"

echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Goalie: 1"
$CLIENT $G_PARAM &
sleep 5

i=2
while [ $i -le 11 ]; do
	echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Player: $i"
	$CLIENT $N_PARAM &
	sleep $SLEEP_TIME
	i=`expr $i + 1`
done
sleep 3

echo ">>>>>>>>>>>>>>>>>>>>>> $TEAM_NAME Coach"
$CLIENT $C_PARAM &

wait

